Upload this ZIP as a new Overleaf project. Keep the folder structure.
Main document: rev1.tex (green) or rev_clean.tex (clean).
Submit supplement.tex as a separate supplementary manuscript.
These generated entry points inline all input files, including tabular rows.
Standalone entry points are optional compatibility copies.
Select response_rev1.tex separately to build the response letter.
Compiler: pdfLaTeX; bibliography: BibTeX.
generated/numbers.tex and all other referenced inputs are included.
The ZIP is source-complete; PDF compilation has not been performed locally.
